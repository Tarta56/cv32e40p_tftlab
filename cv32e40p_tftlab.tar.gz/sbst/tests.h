#ifndef TESTS_H
#define TESTS_H

#define TEST1 0
#define NUMTESTS 1

typedef unsigned int signature_t;

extern signature_t test1(void);


#endif /*TESTS_H */
